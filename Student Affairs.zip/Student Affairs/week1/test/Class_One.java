package test;
import java.util.Scanner;

public class Class_One {

	public static void main(String args[])
	{
		car obj = new car();
		obj.setspeed(30);
		obj.getspeed();
		
	}
	

}
