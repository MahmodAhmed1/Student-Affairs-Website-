const Name = document.getElementById('name')
var regName = /^[a-z ,.'-]+$/i;
const id = document.getElementById('ID')
const email = document.getElementById('email')
const mobile = document.getElementById('telephone')
const gpa = document.getElementById('gpa')

const setError = (element, message) => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = message;
    inputControl.classList.add('error');
    inputControl.classList.remove('success')
}

const setSuccess = element => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = '';
    inputControl.classList.add('success');
    inputControl.classList.remove('error');
};

const isValidEmail = email => {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

const validateInputs = () => {
    const nameValue = Name.value.trim();
    const idValue = id.value.trim();
    const emailValue = email.value.trim();
    const mobileValue = mobile.value.trim();
    const gpaValue = gpa.value.trim();
    var counter = 0;
    if (nameValue === '') {
        setError(Name, 'Name is required');
    } else if (!regName.test(nameValue)) {
        setError(Name, 'Provide a valid name');
    } else {
        setSuccess(Name);
        counter++;
    }
    if (idValue === '') {
        setError(id, 'ID is required');
    }
    else if (isNaN(idValue)) {
        setError(id, 'ID must be an 8 digit number');
    }
    else if (idValue.length != 8) {
        setError(id, 'ID must be 8 digits long');
    } else {
        setSuccess(id);
        counter++;
    }
    if (emailValue === '') {
        setError(email, 'Email is required');
    } else if (!isValidEmail(emailValue)) {
        setError(email, 'Provide a valid email address');
    } else {
        setSuccess(email);
        counter++;
    }
    if (mobileValue === '') {
        setError(mobile, 'Mobile number is required');
    } else if (isNaN(mobileValue)) {
        setError(mobile, 'Mobile number must be an 11 digit number');
    } else if (mobileValue.length != 11) {
        setError(mobile, 'Mobile number must be 11 digits long');
    } else {
        setSuccess(mobile);
        counter++;
    }
    if (gpaValue === '') {
        setError(gpa, 'GPA is required');
    } else if (isNaN(gpaValue)) {
        setError(gpa, 'GPA must be a 4 digit float');
    } else if (parseFloat(gpaValue) > 4 || parseFloat(gpaValue) < 0) {
        setError(gpa, 'Provide a valid GPA (between 0 and 4)');
    } else {
        setSuccess(gpa);
        counter++;
    }
    if (counter == 5) {
        return true;
    }
    else {
        return false;
    }
};
form.addEventListener('submit', e => {
    if (!validateInputs()) {
        swal("Wrong input!", "Please enter valid data", "error");
        e.preventDefault();
    }

});


