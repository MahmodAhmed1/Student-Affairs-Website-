from django.urls import path
from . import views

urlpatterns = [
    path('index', views.index, name='index'),
    path('Update/<str:pk>', views.Update, name='Update'),
    path('mainPage', views.mainPage, name='mainPage'),
    path('student/<str:pk>', views.student, name='student'),
    path('students', views.students, name='students'),
    path('addnewstudents', views.addnewstudents, name='addnewstudents'),
    path('Edit/delete/<str:pk>', views.delete, name='delete'),
    path('Edit/<str:pk>', views.Edit, name='Edit'),
    path('student/Edit/<str:pk>', views.Edit, name='Edit'),
    path('student/Update/<str:pk>', views.Update, name='Update'),
]
