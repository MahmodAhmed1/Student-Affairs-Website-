from msilib.schema import ListView
from this import s
from django.shortcuts import render, redirect
from django.views.generic import ListView
from .models import Student
from .forms import Login, UpdateForm
from django.db.models import Q
from django.contrib import messages
# Create your views here.


def student(request, pk):
    return render(request, 'students/student.html', {'s': Student.objects.get(ID=pk)})


#def students(request):
    
#    return render(request, 'students/students.html', {'stu': Student.objects.all()})

def students(request):
    if 'q' in request.GET:
        q = request.GET['q']
        # data = Data.objects.filter(last_name__icontains=q)
        multiple_q = Q(Q(name__icontains=q) | Q(ID__icontains=q))
        data = Student.objects.filter(multiple_q)
    else:
        data = Student.objects.all().order_by('ID')


    return render(request, 'students/students.html', {'stu': data})



def addnewstudents(request):
    if request.method == 'POST':
        Login(request.POST).save()
        messages.info(request,'Student Added Successfuly')


    return render(request, 'students/addnewstudents.html', {'Lf': Login})


def Update(request, pk):
    stu = Student.objects.get(pk=pk)
    form = UpdateForm(request.POST or None, instance=stu)
    if form.is_valid():
        form.save()
        messages.info(request,'Student Assign Department Successfully')
        return redirect('students')
    return render(request, 'students/Update.html', {'stu': stu, 'form': form})


def Edit(request, pk):
    stu = Student.objects.get(pk=pk)
    form = Login(request.POST or None, instance=stu)
    if form.is_valid():
        form.save()
        messages.info(request,'Student Edit Successfully')
        return redirect('students')
    return render(request, 'students/Edit.html', {'stu': stu, 'form': form})


def index(request):
    return render(request, 'students/index.html')


def mainPage(request):
    return render(request, 'students/mainPage.html')



def delete(request, pk):
    todo = Student.objects.get(ID=pk)
    todo.delete()
    messages.info(request,'Student Deleted Successfully')

    return redirect('/students/students')








# def Edit(request, pk):
#     return render(request, 'students/Edit.html', {'s': Student.objects.get(ID=pk)})


# def Edit(request,pk):
#    todo = Student.objects.get(ID=pk)
#    return redirect('/')







# def delete(request, id):
#    students = Student.objects.get(ID = id)
#    students.delete()
