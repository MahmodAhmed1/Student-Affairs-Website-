package test;

public class car {
	int speeded;	
	public car(){
		
	}
	public void setspeed(int x) {
		speeded=x;
	}
	public void getspeed()
	{
		System.out.println(speeded);
	}
}
